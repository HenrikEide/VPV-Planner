# Sommerjobb

## Over Easy Solar

### Module 1

- Import photo
- Draw bounding box/roof area for solar panels
- Input location, azimuth, roof direction etc.
